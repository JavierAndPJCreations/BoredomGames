# Untangle Game

This game shows how to use canvas and mouse input to drag objects inside canvas. 

This game example is originally from the book [HTML5 Games Development by Examples][1].

Please note that this code was written in 2012 and I didn't followed some best practice in Javasscript programming. It is suggested to learn the concept and update the code to follow latest JavaScript practice.

[1]: http://www.packtpub.com/html5-games-development-using-css-javascript-beginners-guide/book
