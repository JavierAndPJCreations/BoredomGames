# Matching Game

This matching game makes use of CSS3 for the flipping animation.
It is originally from the book [HTML5 Games Development by Examples][1].

![image](http://makzan.github.com/HTML5-Games-Examples/images/css-matching-screen.png)

Please note that this code was written in 2012 and I didn't followed some best practice in Javasscript programming. It is suggested to learn the concept and update the code to follow latest JavaScript practice.

[1]: http://www.packtpub.com/html5-games-development-using-css-javascript-beginners-guide/book
