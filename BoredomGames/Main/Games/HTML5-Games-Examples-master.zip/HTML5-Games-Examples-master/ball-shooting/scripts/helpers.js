var game = this.game || (this.game={});
var createjs = createjs || {};

;(function(game, cjs){
  game.helper = game.helper || {};

}).call(this, game, createjs);