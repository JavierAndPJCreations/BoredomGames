# Ping Pong 

This is a example on making Ping Pong game with jQuery. It supports two players playing on the same computer. This is from the [HTML5 Games Development][1] book.

Please note that this code was written in 2012 and I didn't followed some best practice in Javasscript programming. It is suggested to learn the concept and update the code to follow latest JavaScript practice.

[1]: http://www.packtpub.com/html5-games-development-using-css-javascript-beginners-guide/book
