# Count 99

A simple counting game with EaselJS.

![image](http://makzan.github.com/HTML5-Games-Examples/images/count99-screen.png)