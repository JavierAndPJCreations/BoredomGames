# Multiply Defense

This example uses EaselJS, from the CreateJS suite.

 
