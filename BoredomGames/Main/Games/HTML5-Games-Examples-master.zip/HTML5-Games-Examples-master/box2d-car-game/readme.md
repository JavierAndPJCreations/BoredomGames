# Box2D Car Game

This game integrates Box2D 1.2 into canvas.

This example is originally from the book [HTML5 Games Development by Examples][1].

[1]: http://www.packtpub.com/html5-games-development-using-css-javascript-beginners-guide/book
