# SideTracked Bypass
## THIS MIGHT NOT WORK IN CHROME VERSIONS AFTER 111!
## DOES NOT WORK IN VERSIONS BEFORE 106

1. Go to chrome://flags
2. Search "webview"
3. Enable "Side panel webview"
4. Restart
5. Click side panel button (looks like square with hollow half, in top-right)
6. Click on the dropdown and select "Webview"
7. Have fun!

I also suggest you use [CAUB](https://github.com/red-stone-network/bypass-central/blob/main/chromebooks/caub.md)
to avoid automatic updates screwing you over.

###### Tested in 110.0.5481.181, with GoGuardian installed
###### Discovered by LukasExists
